package com.example.androidanimation;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
    Button button;
    TextView textView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        textView = findViewById(R.id.textV);
        button = findViewById(R.id.button1);
    }

    public void start(View V) {
        Animation animation = AnimationUtils.loadAnimation(getApplicationContext(), R.anim.animation);
        textView.startAnimation(animation);

    }

    public void Zoom(View V) {
        Animation animation = AnimationUtils.loadAnimation(getApplicationContext(), R.anim.zoom);
        textView.startAnimation(animation);

    }

    public void SlideDown(View V) {
        Animation animation = AnimationUtils.loadAnimation(getApplicationContext(), R.anim.slidedown);
        textView.startAnimation(animation);

    }

    public void Blink(View V) {
        Animation animation = AnimationUtils.loadAnimation(getApplicationContext(), R.anim.blink);
        textView.startAnimation(animation);
    }

    public void ClockWise(View V) {
        Animation animation = AnimationUtils.loadAnimation(getApplicationContext(), R.anim.clockwise);
        textView.startAnimation(animation);
    }

    public void sequence(View V) {
        Animation animation = AnimationUtils.loadAnimation(getApplicationContext(), R.anim.sequential);
        textView.startAnimation(animation);

    }
}
