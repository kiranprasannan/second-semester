package com.example.database;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.database.Cursor;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.SearchView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.IllegalFormatCodePointException;

public class MainActivity extends AppCompatActivity {
    EditText name,contact,dob;
    Button insert,update,delete,view;
    DataBaseHelper DB;
    SearchView searchView;
    ListView listView;
    ArrayList<String> list=new ArrayList<>();
    ArrayList<String> namelist=new ArrayList<>();
    String getdata;
    ArrayAdapter<String>adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        name=findViewById(R.id.name);
        contact=findViewById(R.id.contact);
        dob=findViewById(R.id.dob);


        insert=findViewById(R.id.btnInsert);
         delete=findViewById(R.id.btndelete);
       update=findViewById(R.id.btnupdate);
       view=findViewById(R.id.btnview);
       DB=new DataBaseHelper(this);
       insert.setOnClickListener(new View.OnClickListener() {
           @Override
           public void onClick(View v) {
               String nameTXT=name.getText().toString();
               String contactTXT=contact.getText().toString();
               String dobTXT=dob.getText().toString();

               Boolean checkinsertdata=DB.insertuserdata(nameTXT,contactTXT,dobTXT);
               if(checkinsertdata==true){
                   Toast.makeText(MainActivity.this,"New Data Added",Toast.LENGTH_SHORT).show();
               }else {
                   Toast.makeText(MainActivity.this,"New data Not Added",Toast.LENGTH_SHORT).show();
               }
           }
       });
        delete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String nameTXT=name.getText().toString();
                Boolean checkdeletedata=DB.deletedata(nameTXT);
                if(checkdeletedata==true){
                    Toast.makeText(MainActivity.this,"Entry Deleted",Toast.LENGTH_SHORT).show();
                }else {
                    Toast.makeText(MainActivity.this,"Entry not deleted",Toast.LENGTH_SHORT).show();
                }
            }
        });
        view.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Cursor res=DB.getdata();
                if(res.getCount()==0){
                    Toast.makeText(MainActivity.this,"No Entry Exist",Toast.LENGTH_SHORT).show();
                    return;
                }
                StringBuffer buffer=new StringBuffer();
                while ((res.moveToNext())){
                    buffer.append("name:"+res.getString(0)+"\n");
                    buffer.append("contact:"+res.getString(1)+"\n");
                    buffer.append("Date of Birth:"+res.getString(2)+"\n");
                }
                AlertDialog.Builder builder=new AlertDialog.Builder(MainActivity.this);
                builder.setCancelable(true);
                builder.setTitle("user entries");
                builder.setMessage(buffer.toString());
                builder.show();
            }
        });
    }
}