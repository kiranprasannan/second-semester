package com.example.mvc.View;

public interface ILoginView {
    void OnLoginSuccess(String message);
    void OnLoginError(String message);
}
