package com.example.mvc.Controller;

public interface ILoginController {

        void OnLogin(String email,String Password);
}
